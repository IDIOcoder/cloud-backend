for(let i=1;i<=10;i++){

}
let k = 0;
while(k<10){
    k++;
    // if(){
    //     break;
    // }
}