package sku.lesson.spring.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import sku.lesson.spring.dto.MemberDTO;
import sku.lesson.spring.service.MemberService;


@RequestMapping(value = "/member")
@Controller
public class MemberController {

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(HttpServletRequest request) {
		MemberService ms = new MemberService();
		ArrayList<MemberDTO> list = ms.getMemberData();
		HttpSession session = request.getSession();
		session.setAttribute("list", list);
		return "./member/list";
	}
}



