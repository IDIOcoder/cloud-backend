package sku.practice.dbclient;

import java.sql.SQLException;
import java.util.ArrayList;

public class DatabaseClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DatabaseClient client = new DatabaseClient();
		client.testSelect();
	}
	
	public void testSelect() {
		String sql = "select std_no,email,total,mgr_code from gisa limit 10";
		ClientDAO dao = new ClientDAO();
		try {
			ArrayList<String> list = dao.select(sql);
			this.printString(list);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void printString(ArrayList<String> list) {
		// TODO Auto-generated method stub
		for(String temp : list) {
			System.out.println(temp);
		}
	}
	
	

}
