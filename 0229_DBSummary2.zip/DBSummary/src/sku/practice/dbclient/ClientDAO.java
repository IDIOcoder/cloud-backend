package sku.practice.dbclient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClientDAO {
	public ArrayList<String> select(String sql) throws SQLException {
		ArrayList<String> list = null;
		list = new ArrayList<String>();
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			//작업실시(데이터클래스 없이 rs의 내용을 클라이언트 어떻게 전달할 것인가?
			String temp = "";
			for(int i=0;i<4;i++) {
				temp +=rs.getString(i+1);
				if(i!=3) {
					temp += ",";
				}
		    }
			list.add(temp);	
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		
		return list;
  }
	
}
