import React from "react";

function Potato(){
    return <h3>I love potato.</h3>
}

export default Potato;