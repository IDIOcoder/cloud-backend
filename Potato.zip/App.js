import './App.css';

function Food(props){
  return (
    <div>
      <h1>I like {props.name}!</h1>
      <img src={props.picture} alt={props.name}/>
    </div>
  );
}
const foodILike =[
  {
    name : 'potato',
    image : 'https://place-hold.it/200x100/'
  },
  {
    name : 'sweet potato',
    image : 'https://place-hold.it/250x100/'
  },
  {
    name : 'apple',
    image : 'https://place-hold.it/300x100/'
  }
];
function App() {
  return (
    <div>
     <h1>Hello React</h1>
     {foodILike.map((fruit)=>(
       <Food name={fruit.name} picture={fruit.image}/>
     ))}
    </div>
  );
}

export default App;
